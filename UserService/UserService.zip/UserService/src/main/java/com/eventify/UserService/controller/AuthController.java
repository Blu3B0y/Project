package com.eventify.UserService.controller;

import com.eventify.UserService.model.User;
import com.eventify.UserService.service.UserService;
import com.eventify.UserService.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired private UserService service;
    @Autowired private JwtUtil jwtUtil;

    @PostMapping("/register")
    public String register(@RequestBody User user) {
        service.save(user);
        return "Registered!";
    }

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        if (service.authenticate(user)) {
            return jwtUtil.generateToken(user.getEmail());
        }
        return "Invalid credentials";
    }
}
